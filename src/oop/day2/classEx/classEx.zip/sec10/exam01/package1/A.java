package oop.day2.basic.classEx.sec10.exam01.package1;

class A {
}