package oop.day2.basic.classEx.sec10.exam01.package2;
	
import ch06.sec13.exam01.package1.*;
	
public class C {

}