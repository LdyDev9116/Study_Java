package oop.day2.basic.classEx.sec11;

public class CarExample {
	public static void main(String[] args) {
		//객체 생성

		//잘못된 속도 변경

		//올바른 속도 변경

		
		//멈춤

	}
}