package oop.day2.basic.classEx.sec11;

public class Car {
	//필드 선언

	
	//speed 필드의 Getter/Setter 선언

	//stop 필드의 Getter/Setter 선언


}