package oop.day2.basic.classEx.sec04.exam01;

public class CarExample {
	public static void main(String[] args) {


	}
}