package oop.day2.basic.classEx.sec04.exam01;

public class Car {
	//생성자 선언

}