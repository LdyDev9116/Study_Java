package oop.day2.basic.classEx.sec02;

public class StudentExample {
	public static void main(String[] args) {
    //1. Student 타입의 학생객체를 생성 하세요

    //2. 학생 클래스 변수의 주소값을 출력하세요

	}
}