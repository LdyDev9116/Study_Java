package oop.day2.basic.classEx.sec02;

public class Student {
}