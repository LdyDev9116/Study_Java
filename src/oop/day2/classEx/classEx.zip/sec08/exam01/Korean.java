package oop.day2.basic.classEx.sec08.exam01;

public class Korean {
	//인스턴스 final 필드 선언

	
	//인스턴스 필드 선언


	//생성자 선언

}