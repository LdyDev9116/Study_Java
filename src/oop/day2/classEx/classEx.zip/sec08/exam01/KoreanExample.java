package oop.day2.basic.classEx.sec08.exam01;

public class KoreanExample {
	public static void main(String[] args) {
		//객체 생성 시 주민등록번호와 이름 전달

		//필드값 읽기


		//Final 필드는 값을 변경할 수 없음


		//final 필드는 값 변경 가능

	}
}