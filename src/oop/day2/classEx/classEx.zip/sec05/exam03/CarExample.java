package oop.day2.basic.classEx.sec05.exam03;

public class CarExample {
	public static void main(String[] args) {
		//Car 객체 생성
		Car myCar = new Car();

		//리턴값이 없는 setGas() 메소드 호출


		//isLeftGas() 메소드를 호출해서 받은 리턴값이 true일 경우 if 블록 실행

		

	}
}