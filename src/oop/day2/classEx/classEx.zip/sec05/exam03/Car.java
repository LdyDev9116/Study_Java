package oop.day2.basic.classEx.sec05.exam03;

public class Car {
	//필드 선언


	//리턴값이 없는 메소드로 매개값을 받아서 gas 필드값을 변경


	//리턴값이 boolean인 메소드로 gas 필드값이 0이면 false를, 0이 아니면 true를 리턴


	//리턴값이 없는 메소드로 gas 필드값이 0이면 return 문으로 메소드를 종료


}