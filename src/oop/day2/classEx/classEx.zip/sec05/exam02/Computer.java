package oop.day2.basic.classEx.sec05.exam02;

public class Computer {
	//가변길이 매개변수를 갖는 메소드 선언

}