package oop.day2.basic.classEx.sec05.exam04;

public class Calculator {
	//정사각형의 넓이
	double areaRectangle(double width) {

		return 0.0;

	}
	
	//직사각형의 넓이
	double areaRectangle(double width, double height) {
		return 0.0
	}
}