package oop.day2.basic.classEx.sec09.hyundai;

//import 문으로 다른 패키지 클래스 사용을 명시

public class Car {
	//부품 필드 선언

}