package oop.day2.basic.classEx.sec09.kumho;

public class Tire {
}