package oop.day2.basic.classEx.sec09.hankook;

public class SnowTire {
}