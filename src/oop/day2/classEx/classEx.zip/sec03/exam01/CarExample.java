package oop.day2.basic.classEx.sec03.exam01;

public class CarExample {
	public static void main(String[] args) {
		//Car 객체 생성

		//Car 객체의 필드값 읽기

	}
}