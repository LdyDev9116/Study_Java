package oop.day2.basic.classEx.sec03.exam01;

public class Car {
	//필드 선언

}