package oop.day2.basic.classEx.sec01;

class SportCar{}
class Tire1{}


public class SportCarMain {
    public static void main(String[] args) {

    }
}
