package oop.day2.basic.classEx.sec01;

public class SportsCar {
}

class Tire {
}

