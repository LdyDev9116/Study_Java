package oop.day2.basic.classEx.sec06;

public class CarExample {
	public static void main(String[] args) {

	}
}