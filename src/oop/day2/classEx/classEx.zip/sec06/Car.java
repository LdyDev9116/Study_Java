package oop.day2.basic.classEx.sec06;

public class Car {
	//필드 선언


	//생성자 선언
	 //매개변수를 필드에 대입(this 생략 불가)

	
	//메소드 선언
	 //매개변수를 필드에 대입(this 생략 불가)



}