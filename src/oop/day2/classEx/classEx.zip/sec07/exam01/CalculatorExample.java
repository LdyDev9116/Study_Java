package oop.day2.basic.classEx.sec07.exam01;

public class CalculatorExample {
	public static void main(String[] args) {

	}
}