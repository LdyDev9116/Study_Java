package oop.day2.basic.classEx.sec07.exam02;

public class TelevisionExample {
	public static void main(String[] args) {
		System.out.println(Television.info);
		}	
}