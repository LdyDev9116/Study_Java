package oop.day2.basic.classEx.sec12;

public class Singleton {
	//private 접근 권한을 갖는 정적 필드 선언과 초기화


	//private 접근 권한을 갖는 생성자 선언


	//public 접근 권한을 갖는 정적 메소드 선언

}